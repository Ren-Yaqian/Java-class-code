package com.peixinchen.javase.learn_extends;

public class 狗 extends 逮老鼠动物 {
    public void 拆家() {
        System.out.println("我在拆家");
    }
}
