package com.peixinchen.javase.learn_extends;

public class 麻雀 extends 动物 {
    public void 跳() {
        System.out.println("我在跳");
    }
}
