package com.peixinchen.javase.learn_extends;

public class 动物 {
    public void 叫() {
        System.out.println("我在叫");
    }
}
