package com.peixinchen.javase.learn_extends;

public class 逮老鼠动物 extends 动物 {
    public void 走() {
        System.out.println("我在走");
    }

    public void 跑() {
        System.out.println("我在跑");
    }

    public void 逮老鼠() {
        System.out.println("逮老鼠");
    }
}
