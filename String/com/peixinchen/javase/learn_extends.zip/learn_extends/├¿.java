package com.peixinchen.javase.learn_extends;

public class 猫 extends 逮老鼠动物 {
    public void 卖萌() {
        System.out.println("我在卖萌");
    }
}
